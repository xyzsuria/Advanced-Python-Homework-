def cubes(a):
    return 6*a*a