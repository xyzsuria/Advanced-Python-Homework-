def spheres(r):
    return 4*3.14*r*r