def cuboids(a,b,c):
    return 2*(a*b+a*c+b*c)