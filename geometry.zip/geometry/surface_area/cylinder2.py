def cylinders(r,h):
    return 2*3.14*r*r+r*h