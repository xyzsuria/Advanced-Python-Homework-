import circle1
import rectangle1
import square1
import triangles1