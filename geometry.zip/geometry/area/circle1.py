def circle(r):
    return 3.14*r*r 