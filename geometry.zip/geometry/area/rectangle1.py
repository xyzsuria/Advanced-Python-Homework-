def rectangle(a,b):
    return a*b
