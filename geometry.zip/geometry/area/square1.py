def square2(a):
    return a*a