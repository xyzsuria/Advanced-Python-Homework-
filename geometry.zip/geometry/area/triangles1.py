def triangles(h,l):
    return h*l*0.5