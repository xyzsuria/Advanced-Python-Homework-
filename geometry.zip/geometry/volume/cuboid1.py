def cuboid(a,b,c):
    return a*b*c