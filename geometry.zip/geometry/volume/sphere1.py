def sphere(r):
    return 3/4*(3.14*r*r*r)