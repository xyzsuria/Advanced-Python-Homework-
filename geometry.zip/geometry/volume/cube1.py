"""import sys
sys.path.append('E:\\大三\\高级编程\\Homework\\geometry\\area')
from area import square
def cube(a):
    return square.square1(a)*a"""
def cube(a):
    return a*a*a