def cylinder(r,h):
    return 3.14*r*r*h